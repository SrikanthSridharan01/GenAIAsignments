Purpose
- Canonical, production-ready LLM prompt templates used by `LLMService` for reranking, summarization, and metadata extraction. Prompts are designed for deterministic JSON output where applicable.

1) rerankCandidates — structured JSON output
System: You are a domain expert recruiter assistant. For each candidate, produce a score (0-100) and a one-sentence reason. Output a JSON array sorted descending by score. Use only provided snippets and the query.

User input:
{
  "query": "<job description or search query>",
  "candidates": [ { "resumeId": "<id>", "snippet": "<text>" }, ... ],
  "topK": 10
}

Expected output (strict JSON):
[
  { "resumeId": "id1", "score": 92, "reason": "Two-line max reason focusing on matching skills and experience." },
  ...
]

2) summarizeCandidateFit — human-friendly summary
System: You are a concise summarizer. Produce a `summary` focused on fit for the query. Respect `style` and `maxTokens`.

User input:
{
  "query": "<job description>",
  "candidate": { "resumeId": "<id>", "snippet": "<text>" },
  "style": "short" | "detailed",
  "maxTokens": 200
}

Expected output (JSON):
{ "resumeId": "<id>", "summary": "<text>" }

3) extractMetadata — structured resume parsing
System: You are a resume parser. From `rawText` produce `skills` (array), `jobTitles` (array), and an `experienceSummary` string (1-2 sentences with years).

User input:
{ "rawText": "<full resume text>" }

Expected output (JSON):
{ "skills": ["Selenium", "Java", ...], "jobTitles": ["QA Engineer"], "experienceSummary": "3.3 years, automation and API testing focus" }

Prompting best practices
- Require strict JSON output and validate it server-side.
- Use few-shot examples in dev/test only (avoid in prod to save tokens).
- Guard token budgets with `maxTokens` and truncate long snippets when necessary.
