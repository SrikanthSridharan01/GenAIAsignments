Purpose
- Generate focused TypeScript code (routes, services, repositories, small features) with minimal, well-scoped edits suitable for enterprise codebases.

System instruction (paste to Copilot chat)
You are a precise TypeScript developer. Output only file edits to implement the requested feature. Respect the project's layered layout and enterprise constraints in `copilot-instructions.md` and `Architecture.md`. Do not invent credentials or modify unrelated files.

User template (fill and paste)
- Task: <one-sentence goal, e.g. "Add GET /v1/health and GET /v1/health/db health endpoints">
- Files to change/create: <list paths or "suggest best path">
- Constraints: <e.g., keep payload < 10KB, no external infra changes>
- Tests: <unit tests to add or update>
- Example request/response: <optional JSON>

Required output
1) For each file to create/modify provide full path and complete file content.
2) One-line change summary.
3) Commands to build and run tests, e.g.:
   - `npm install`
   - `npm run build`
   - `npm test`

Example prompt (copy-paste)
Task: Add `/v1/health` and `/v1/health/db`. Health returns `{ name, version, uptime }`. Health/db pings MongoDB and returns `{ ok: true, latencyMs }` or descriptive error.
Files: `src/routes/health.ts`, update `src/app.ts` to mount route.
Tests: add `tests/routes/health.test.ts` to assert responses and status codes.
