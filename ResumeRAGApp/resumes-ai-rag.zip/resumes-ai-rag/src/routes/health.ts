import { Router, Request, Response } from 'express';
import { config } from '../config';
import { pingMongo } from '../services/mongo';

const router = Router();

router.get('/', (_req: Request, res: Response) => {
  res.json({ name: config.appName, version: config.appVersion, uptime: process.uptime() });
});

router.get('/db', async (_req: Request, res: Response) => {
  const result = await pingMongo();
  if (!result.ok) {
    return res.status(500).json({ ok: false, error: result.error });
  }
  return res.json({ ok: true, latencyMs: result.latencyMs });
});

export default router;
