import { createApp } from './app';
import { config } from './config';
import { connectMongo } from './services/mongo';

async function start() {
  try {
    // Initialize DB connection
    await connectMongo();

    const app = createApp();
    const port = config.port;
    app.listen(port, () => {
      // eslint-disable-next-line no-console
      console.log(`${config.appName} v${config.appVersion} listening on ${port}`);
    });
  } catch (err) {
    // eslint-disable-next-line no-console
    console.error('Failed to start server', err);
    process.exit(1);
  }
}

start();
