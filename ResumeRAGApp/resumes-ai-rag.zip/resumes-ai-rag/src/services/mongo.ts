import { MongoClient, Db } from 'mongodb';
import { config } from '../config';

let client: MongoClient | null = null;
let db: Db | null = null;

export async function connectMongo(): Promise<Db> {
  if (db) return db;
  client = new MongoClient(config.mongodbUri);
  await client.connect();
  db = client.db();
  return db;
}

export async function pingMongo(): Promise<{ ok: boolean; latencyMs?: number; error?: string }> {
  if (!client) {
    try {
      await connectMongo();
    } catch (err: any) {
      return { ok: false, error: String(err?.message || err) };
    }
  }
  const start = Date.now();
  try {
    // ``admin` command ping``
    // In MongoDB driver v5, db.command works for ping
    await db!.command({ ping: 1 });
    const latencyMs = Date.now() - start;
    return { ok: true, latencyMs };
  } catch (err: any) {
    return { ok: false, error: String(err?.message || err) };
  }
}

export async function closeMongo(): Promise<void> {
  if (client) {
    await client.close();
    client = null;
    db = null;
  }
}

export function getDb(): Db | null {
  return db;
}
