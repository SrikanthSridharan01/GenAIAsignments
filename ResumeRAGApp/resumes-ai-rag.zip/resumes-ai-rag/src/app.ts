import express from 'express';
import bodyParser from 'body-parser';
import healthRouter from './routes/health';
import { requestIdMiddleware } from './middleware/requestId';
import { loggerMiddleware } from './middleware/logger';

export function createApp() {
  const app = express();

  app.use(bodyParser.json({ limit: '100kb' }));
  app.use(requestIdMiddleware);
  app.use(loggerMiddleware);

  // Versioned API routes
  app.use('/v1/health', healthRouter);

  // Basic 404
  app.use((req, res) => {
    res.status(404).json({ error: 'Not Found' });
  });

  // Error handler
  // eslint-disable-next-line @typescript-eslint/no-unused-vars
  app.use((err: any, _req: any, res: any, _next: any) => {
    // eslint-disable-next-line no-console
    console.error(err);
    res.status(500).json({ error: 'Internal Server Error' });
  });

  return app;
}
