import fs from 'fs';
import path from 'path';
import dotenv from 'dotenv';

dotenv.config();

const pkgPath = path.resolve(__dirname, '../../package.json');
let pkg: { name?: string; version?: string } = {};
try {
  const raw = fs.readFileSync(pkgPath, 'utf-8');
  pkg = JSON.parse(raw);
} catch (err) {
  // ignore
}

export const config = {
  appName: process.env.APP_NAME || pkg.name || 'resumes-ai-rag',
  appVersion: process.env.APP_VERSION || pkg.version || '0.0.0',
  port: Number(process.env.PORT || 3000),
  nodeEnv: process.env.NODE_ENV || 'development',
  mongodbUri: process.env.MONGODB_URI || 'mongodb://localhost:27017/resumes',
  mistralApiKey: process.env.MISTRAL_API_KEY || '',
  mistralEmbedModel: process.env.MISTRAL_EMBED_MODEL || 'mistral-embed',
};
