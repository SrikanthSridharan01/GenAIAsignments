import { Request, Response, NextFunction } from 'express';

export function loggerMiddleware(req: Request, res: Response, next: NextFunction) {
  res.on('finish', () => {
    const requestId = (req as any).requestId || null;
    const start = (req as any).startTime || Date.now();
    const durationMs = Date.now() - start;
    const payload = {
      requestId,
      method: req.method,
      endpoint: req.originalUrl,
      statusCode: res.statusCode,
      durationMs,
    };
    // simple console JSON log — replace with structured logger in prod
    // eslint-disable-next-line no-console
    console.log(JSON.stringify(payload));
  });
  next();
}
