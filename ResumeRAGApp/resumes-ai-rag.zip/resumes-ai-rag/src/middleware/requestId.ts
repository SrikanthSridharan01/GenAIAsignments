import { Request, Response, NextFunction } from 'express';
import { v4 as uuidv4 } from 'uuid';

export function requestIdMiddleware(req: Request, _res: Response, next: NextFunction) {
  (req as any).requestId = uuidv4();
  (req as any).startTime = Date.now();
  next();
}
